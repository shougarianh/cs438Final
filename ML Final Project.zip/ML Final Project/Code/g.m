function sigmoid = g(x)
    sigmoid = 1 ./ (1 + exp(-x));
end