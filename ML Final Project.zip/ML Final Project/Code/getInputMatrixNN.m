function input_matrix = getInputMatrixNN()
        letters = ["A" "B" "C" "D" "E" "F" "G" "H" "I" "J" "K" "L" "M" "N" "O" "P" "Q" "R" "S" "T" "U" "V" "W" "X" "Y" "Z"];
        imagefiles = dir("Data/NNDATA/A/*.png");
        im = loadImageNN("Data/NNDATA/A/", imagefiles);
        input_matrix = im;
        for i = 2 : 26
            directory_string = strcat("Data/NNDATA/" , letters(i), "/*.png");
            load_string = strcat("Data/NNDATA/" , letters(i), "/");
            imagefiles = dir(directory_string);
            im = loadImageNN(load_string, imagefiles);
            input_matrix = [input_matrix ; im];
        end

end