function Theta = initThetaNN(n)
    Theta = cell(n - 1,1);

    for l = 1 : length(n) - 1
        row_len = n(l + 1);
        col_len = n(l) + 1;
        Theta{l} =  0.1 * rand(row_len, col_len);
    end

end