 function [accuracy] = returnLogisticAccuracy(estimates)
    num_correct = 0;
    truePositive = [];
    trueNegative = [];
    falsePositive = [];
    falseNegative = [];
    for i = 1 : 100
        if (estimates(i) > 0.5)
            truePositive = [truePositive i];
            num_correct++;
        else
            falseNegative = [falseNegative i];
        end
    end

    for i = 100 : 150
        if (estimates(i) < 0.5)
            num_correct++;
            trueNegative = [trueNegative i];
        else 
            falsePositive = [falsePositive i];
        end
    end

    %%%% write roc data

    %csvwrite("estimates.txt", estimates);
    %csvwrite("truePositive.txt", truePositive);
    %csvwrite("trueNegative.txt", trueNegative);
    %csvwrite("falsePositive.txt", falsePositive);
    %csvwrite("falseNegative.txt", falseNegative);

    %pause;
    accuracy = num_correct / length(estimates);

end
