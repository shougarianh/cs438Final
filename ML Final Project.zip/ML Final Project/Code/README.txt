Inorder to replicate the results do the following:

For neural network, run the following command:
    octave runNN.m
Everything else should be automated. To see the parameter tuning graphs, uncomment the following
on line 31 in runNN.m
    %optimizeNNParameters(Theta, input_matrix, X_Validation, Y, Y_validation);


For logistic regression, run the following command:
    octave runLogistic.m



NOTE: ALL OF THE DATA FILES HAVE BEEN COMPRESSED FOR SUBMISSION. PLEASE UNZIP THEM TO CONTINUE.