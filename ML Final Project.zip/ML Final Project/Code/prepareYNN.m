function Y = prepareYNN(y)
    k = length(y);
    Y = zeros(max(y), k);
    for i = 1:k
        Y(y(i), i) = 1;

    end
end