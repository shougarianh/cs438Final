function y = getYNN()
    y = ones(500, 1);
    for i = 2 : 26
        values = ones(500, 1) * i;
        y = [y ; values];
end