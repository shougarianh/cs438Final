clear; close all; clc
pkg load image;
% Programming exercise 2

%printf('Loading the data...\n');

letters = ["A" "B" "C" "D" "E" "F" "G" "H" "I" "J" "K" "L" "M" "N" "O" "P" "Q" "R" "S" "T" "U" "V" "W" "X" "Y" "Z"];

%%%%%%%%%%%%%%%%%%% Training %%%%%%%%%%%%%%%%%%%%%%%%%
theta_matrix = [];


costs = [];
for i = 1 : 26
    printf(strcat("\nTraining...", letters(i),  "...\n"));
    imagefiles = dir(strcat("Data/Train/", letters(i),"/*.png"));
    im = loadImage(strcat("Data/Train/", letters(i), "/"), imagefiles);
    X_MATRIX = loadData(im);
    [theta, costs] = runLogisticGradient(X_MATRIX);
    theta_matrix = [theta_matrix ; theta'];
    accuracy = returnLogisticAccuracy(h(theta, X_MATRIX));
    printf("Training accuracy: %d\n\n", accuracy);
end





%%%%%%%%%%%%%%%%%%% TESTING %%%%%%%%%%%%%%%%%%%%%%%%%

total_accuracy = 0;

for i = 1 : 26

    printf(strcat("Testing...", letters(i), "...\n"));
    image_test_files = dir(strcat("Data/Test/", letters(i), "/*.png"));
    im_test = loadImage(strcat("Data/Test/", letters(i), "/"), image_test_files);
    X_MATRIX_TEST = loadData(im_test);
    [letter, biggest_accuracy] = testGetLogisticLetter(X_MATRIX_TEST, theta_matrix);
    total_accuracy += biggest_accuracy;
    printf("result: %s with accuracy: %d\n\n", letter, biggest_accuracy);
end

total_accuracy = total_accuracy / 26;

fprintf("Total average training accuracy is: %f\n", total_accuracy);

pause;
