function cost = JNN(Theta, estimates, Y, lambda)
    m = length(estimates);
    first_part = (sum(sum(-ln(estimates) .* Y - ln((1 - estimates)) .* (1 - Y))))/m;
    second_part = 0;
    for i = 2 : length(Theta)
        second_part += sum(sum(Theta{i} .^ 2));
    cost = first_part + (lambda / (2*m)) * second_part;

end
