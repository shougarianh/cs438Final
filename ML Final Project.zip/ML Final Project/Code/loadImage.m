function images = loadImage(directory, imagefiles)
    numfiles = length(imagefiles);
    for i = 1 : numfiles
        image = imread(strcat(directory, imagefiles(i).name));
        image = imcomplement(image);
        image = image(:,:,1);
        images(i, :) = image(:)';
    end
end